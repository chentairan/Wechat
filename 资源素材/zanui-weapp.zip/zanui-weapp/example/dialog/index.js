var app = getApp()

Page({
  data: {
    showDialog: false
  },

  toggleDialog() {
    this.setData({
      showDialog: !this.data.showDialog
    });
  },

  onLoad: function () {

  },

  onShow: function() {
  },
})
